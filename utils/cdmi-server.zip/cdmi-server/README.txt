Before deploying the service to a container, the applicationContext.xml file should be edited, 
the beans containerDao and dataObjectDao must have a valid path that will be the base directory to the server. 
To do so, edit the property baseDirectoryName.

The server must be the root application of your container.

  